# Learning Unity basics - Hollow Fire

A 2D jump'n'run Unity game. Meant to improve game developing skills and unity knowledge. Basicially just trying out tools in Unity.

Some basic features implemented:

*	Movement, Jumping
*	Enemy's moving around
*	Main Character can shoot Fireballs
*	Enemy's and the character can die
*	Main Character can change his size, to overcome obstacles

Future feature I may work on:

*	Sound
*	Simple User-Interface
*	Enemy AI (Chasing the character)


Nothing impressive to see here :)

![Alt Text](https://github.com/TheOneNix/HollowFire/blob/master/gameplay.gif)